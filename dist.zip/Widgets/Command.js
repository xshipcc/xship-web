import e from"../Core/DeveloperError.js";function r(){this.canExecute=void 0,this.beforeExecute=void 0,this.afterExecute=void 0,e.throwInstantiationError()}export default r;
