import r from"../ThirdParty/knockout.js";function s(u,t,i,n,o){return i.call(n,u[t]),r.getObservable(u,t).subscribe(i,n,o)}export default s;
